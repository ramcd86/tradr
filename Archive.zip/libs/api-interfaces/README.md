# api-interfaces

This library was generated with [Nx](https://nx.dev).

## Running lint

Run `nx lint api-interfaces` to execute the lint via [ESLint](https://eslint.org/).
