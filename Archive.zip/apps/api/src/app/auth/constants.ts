export const jwtConstants = {
  secret: 'e7ac0804-3a0f-47f7-a95c-12b3a6896d3b',
};
